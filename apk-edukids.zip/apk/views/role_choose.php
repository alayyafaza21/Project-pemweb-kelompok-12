<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Pilih Peran - EduKids</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center min-vh-100">

  <div class="container" style="max-width: 500px;">
    <div class="card p-4 shadow-sm">
      <h4 class="text-center text-primary mb-4">Pilih Peran Anda</h4>
      <form action="index.php?page=choose_role" method="POST">
        <div class="d-grid gap-3">
          <button type="submit" name="role" value="teacher" class="btn btn-outline-primary">
            <i class="fas fa-chalkboard-teacher me-2"></i> Masuk sebagai Guru
          </button>
          <button type="submit" name="role" value="student" class="btn btn-outline-success">
            <i class="fas fa-user-graduate me-2"></i> Masuk sebagai Murid
          </button>
        </div>
      </form>

      <div class="text-center mt-3">
        <a href="index.php?page=logout" class="text-decoration-none text-muted">Logout</a>
      </div>
    </div>
  </div>

</body>
</html>
