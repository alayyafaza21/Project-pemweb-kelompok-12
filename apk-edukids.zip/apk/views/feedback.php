<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>EDUKIDS - Feedback</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>

<div class="container mt-5 text-center">
  <h2>EDUKIDS</h2>
  <p class="text-muted">Kirim feedback berdasarkan mata pelajaran</p>

  <div class="row row-cols-2 g-3 mb-4">
    <?php
    $mapels = ['Matematika', 'Biologi', 'Bahasa Indonesia', 'PKN'];
    foreach ($mapels as $mapel): ?>
      <div class="col">
        <button class="btn btn-light border w-100 p-3" onclick="showForm('<?php echo $mapel; ?>')"><?php echo $mapel; ?></button>
      </div>
    <?php endforeach; ?>
  </div>

  
  <form id="feedbackForm" class="d-none text-start" action="index.php?page=kirim" method="POST">
    <input type="hidden" name="mapel" id="mapelInput">
    <h4 id="mapelTitle" class="text-center mb-3"></h4>

    <div class="mb-2">
      <input type="text" class="form-control" name="nama" placeholder="Nama" required>
    </div>
    <div class="mb-2">
      <input type="text" class="form-control" name="kelas" placeholder="Kelas" required>
    </div>
    <div class="mb-2">
      <input type="number" class="form-control" name="nilai" placeholder="Nilai (1-100)" required>
    </div>
    <div class="mb-3">
      <textarea class="form-control" name="komentar" placeholder="Komentar dari guru..." rows="4"></textarea>
    </div>
    <button class="btn btn-success w-100 mb-2" type="submit">Kirim</button>
    <button type="button" class="btn btn-secondary w-100" onclick="hideForm()">Batal</button>
  </form>
</div>

<script>
  function showForm(mapel) {
    document.getElementById("mapelInput").value = mapel;
    document.getElementById("mapelTitle").innerText = "Feedback untuk " + mapel;
    document.getElementById("feedbackForm").classList.remove("d-none");
  }

  function hideForm() {
    document.getElementById("feedbackForm").classList.add("d-none");
  }
</script>

</body>
</html>
