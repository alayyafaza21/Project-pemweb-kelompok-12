<?php
require_once 'controller/AppController.class.php';

$page = $_GET['page'] ?? 'beranda';

$controller = new AppController();
$controller->handleRequest($page);
