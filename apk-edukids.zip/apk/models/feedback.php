<?php
require_once 'config/Database.php';

class Feedback
{
    private $conn;
    private $table = "feedback";

    public function __construct()
    {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function save($data)
    {
        $query = "INSERT INTO {$this->table} (nama, kelas, nilai, komentar, mata_pelajaran) 
                VALUES (:nama, :kelas, :nilai, :komentar, :mata_pelajaran)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nama', $data['nama']);
        $stmt->bindParam(':kelas', $data['kelas']);
        $stmt->bindParam(':nilai', $data['nilai']);
        $stmt->bindParam(':komentar', $data['komentar']);
        $stmt->bindParam(':mata_pelajaran', $data['mata_pelajaran']);
        return $stmt->execute();
    }
}
