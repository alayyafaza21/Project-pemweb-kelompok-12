const FeedbackModel = require("../models/feedbackModel");

exports.kirimFeedback = (req, res) => {
  FeedbackModel.create(req.body, (err, result) => {
    if (err) return res.status(500).json({ success: false, error: err });
    res.status(200).json({ success: true, message: "Feedback berhasil dikirim" });
  });
};

exports.ambilFeedback = (req, res) => {
  FeedbackModel.getAll((err, result) => {
    if (err) return res.status(500).json({ success: false, error: err });
    res.status(200).json(result);
  });
};
