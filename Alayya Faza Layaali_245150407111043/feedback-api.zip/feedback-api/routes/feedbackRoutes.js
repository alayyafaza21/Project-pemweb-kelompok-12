const express = require("express");
const router = express.Router();
const controller = require("../controllers/feedbackController");

router.post("/feedback", controller.kirimFeedback);
router.get("/feedback", controller.ambilFeedback);

module.exports = router;
