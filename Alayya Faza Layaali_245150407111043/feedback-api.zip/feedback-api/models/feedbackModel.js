const db = require("../db");

const FeedbackModel = {
  create: (feedbackData, callback) => {
    const { nama, kelas, nilai, mapel, komentar } = feedbackData;
    const sql = `INSERT INTO feedback (nama, kelas, nilai, mapel, komentar) VALUES (?, ?, ?, ?, ?)`;
    db.query(sql, [nama, kelas, nilai, mapel, komentar], callback);
  },

  getAll: (callback) => {
    db.query("SELECT * FROM feedback", callback);
  }
};

module.exports = FeedbackModel;
